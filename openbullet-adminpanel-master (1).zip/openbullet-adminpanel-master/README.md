# OpenBullet Admin Panel
Admin Panel for the OpenBullet API.

Go [here](https://openbullet.github.io/remote.html) to learn how to use this.
